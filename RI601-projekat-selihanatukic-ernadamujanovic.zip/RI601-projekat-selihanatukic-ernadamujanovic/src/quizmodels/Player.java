package quizmodels;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Player {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@OneToOne(cascade={CascadeType.PERSIST,CascadeType.REMOVE})
	private Person person;
	@OneToMany(mappedBy="player")
	private Collection<Inbox> results;
	
	public Player(){
		super();
	}
	
	public Player(Person person){
		this.person = person;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public Person getPerson() {
		return person;
	}
	
	public void setPerson(Person person) {
		this.person = person;
	}
	
	public Collection<Inbox> getResults() {
		return results;
	}
	
	public void setResults(Collection<Inbox> results) {
		this.results = results;
	}	
}
