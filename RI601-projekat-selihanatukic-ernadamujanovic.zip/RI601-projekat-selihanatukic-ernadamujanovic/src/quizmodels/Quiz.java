package quizmodels;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Quiz {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
 private int id;
 private String headline;
 private String icon;
 private boolean isActive;
 private String description;
 @OneToMany(mappedBy="quiz")
 private Collection<Question> questions;
 @OneToMany(mappedBy="quiz")
 private Collection<Inbox> results;
 @ManyToOne
 private User user;

 public Quiz(){
	 super();
 }
 
 public Quiz(String headline, String icon, boolean isActive, String description, User user){
	 this.headline = headline;
	 this.icon = icon;
	 this.isActive = isActive;
	 this.description  = description;
	 this.user = user;
 }
 
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getHeadline() {
	return headline;
}
public void setHeadline(String headline) {
	this.headline = headline;
}
public String getIcon() {
	return icon;
}
public void setIcon(String icon) {
	this.icon = icon;
}
public boolean isActive() {
	return isActive;
}
public void setActive(boolean isActive) {
	this.isActive = isActive;
}
public Collection<Question> getQuestions() {
	return questions;
}
public void setQuestions(Collection<Question> questions) {
	this.questions = questions;
}
public Collection<Inbox> getResults() {
	return results;
}
public void setResults(Collection<Inbox> results) {
	this.results = results;
}
public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
 
}
