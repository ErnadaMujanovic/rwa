package quizmodels;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Question {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String question;
	private int time;
	private int pointForCorrectAnswer;
	private int numberOfQuestion;
	@ManyToOne
	private Quiz quiz;
	@OneToMany(mappedBy="question")
	private Collection<Answer> answers;
	
	public Question(){
		super();
	}
	
	public Question(String question, int time, int pointForCorrectAnswer, int numberOfQuestion, Quiz quiz){
		this.question = question;
		this.time = time;
		this.pointForCorrectAnswer = pointForCorrectAnswer;
		this.numberOfQuestion = numberOfQuestion;
		this.quiz = quiz;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getPointForCorrectAnswer() {
		return pointForCorrectAnswer;
	}
	public void setPointForCorrectAnswer(int pointForCorrectAnswer) {
		this.pointForCorrectAnswer = pointForCorrectAnswer;
	}
	public int getNumberOfQuestion() {
		return numberOfQuestion;
	}
	public void setNumberOfQuestion(int numberOfQuestion) {
		this.numberOfQuestion = numberOfQuestion;
	}
	public Quiz getQuiz() {
		return quiz;
	}
	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}
	public Collection<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(Collection<Answer> answers) {
		this.answers = answers;
	}
	
}
