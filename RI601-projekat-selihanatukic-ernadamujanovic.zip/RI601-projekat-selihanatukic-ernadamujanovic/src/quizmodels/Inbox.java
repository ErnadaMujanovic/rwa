package quizmodels;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Inbox {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int score;
	@ManyToOne
	private Player player;
	@ManyToOne
	private Quiz quiz;
	
	public Inbox(){
		super();
	}
	
	public Inbox(int score, Player player, Quiz quiz){
		this.score = score;
		this.player = player;
		this.quiz = quiz;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Player getPlayer() {
		return player;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	public Quiz getQuiz() {
		return quiz;
	}
	public void setQuiz(Quiz quiz) {
		this.quiz = quiz;
	}

	

}
