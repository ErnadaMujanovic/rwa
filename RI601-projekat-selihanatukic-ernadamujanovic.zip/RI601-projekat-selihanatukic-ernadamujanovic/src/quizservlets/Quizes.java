package quizservlets;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import quizdao.AnswerDao;
import quizdao.QuestionDao;
import quizdao.QuizDao;
import quizmodels.Answer;
import quizmodels.Question;
import quizmodels.Quiz;
import quizmodels.User;

/**
 * Servlet implementation class Quizes
 */
@WebServlet("/admin/quizes/*")
@MultipartConfig
public class Quizes extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuizDao quizDao = new QuizDao();
	private QuestionDao questionDao = new QuestionDao();
	private static final String SAVE_DIR = "images";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Quizes() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String event = request.getParameter("event");

		if (event != null) {

			switch (event) {
			case "getQuestions":
				String quizId = request.getParameter("quizId");

				List<Question> questions = questionDao.getQuestions(Integer.parseInt(quizId));
				for (Question question : questions) {
					question.setQuiz(null);
					question.setAnswers(null);
				}
				
				response.getWriter().println(new Gson().toJson(questions));

				break;
				
			}
		}
		else {
		request.setAttribute("quizes", quizDao.getQuizes((User) request.getSession().getAttribute("user")));
		request.getRequestDispatcher("/quizes.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String quizId = request.getParameter("quizId");
		String event = request.getParameter("event");
		String[] questions =request.getParameterValues("questions[]");		
		
		if(event!=null && event.equals("orderQuestions")) {
		  if(questions!=null) {
		  	for(int i = 0; i < questions.length;i++) {
	          Question question = questionDao.getQuestion(Integer.parseInt(questions[i]));
			  question.setNumberOfQuestion(i+1);
			  questionDao.update(question);
     		 }
	      }
		}
		
		if (quizId != null) {
			System.out.println("event"+event);
			if (event == null) {  
				System.out.println("create");
				String headline = request.getParameter("headline");
				String description = request.getParameter("description");
				String active = request.getParameter("active");
				Part part = request.getPart("img");
				String appPath = request.getServletContext().getRealPath("");
				String savePath = appPath + File.separator + SAVE_DIR;
				File fileSaveDir = new File(savePath);
				Quiz quiz = new Quiz();
				
				if (!quizId.equals("")) 
					quiz = quizDao.getQuiz(Integer.parseInt(quizId));
				
				if(part.getSize()!=0) 
				{
				  if (!fileSaveDir.exists()) 
					fileSaveDir.mkdir();
			    	

				String imageName = request.getParameter("image");
				String path = "";
				if (!imageName.equals("")) {
					path = savePath + File.separator + imageName;
					part.write(path);
					quiz.setIcon(imageName);

				  }
		     	}

				quiz.setHeadline(headline);
				if (active != null)
					quiz.setActive(true);
				else
					quiz.setActive(false);
				quiz.setUser((User) request.getSession().getAttribute("user"));
				quiz.setDescription(description);
			
				if (quizId.equals("")) 
					quizDao.save(quiz);
				 else 
					quizDao.update(quiz);
				
			}
			else {
				System.out.println("delete");

				quizDao.remove(Integer.parseInt(quizId));
			}
			doGet(request, response);

		}

	}

}
