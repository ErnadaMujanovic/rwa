package quizservlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import quizdao.AnswerDao;
import quizdao.QuestionDao;
import quizdao.QuizDao;
import quizmodels.Answer;
import quizmodels.Question;
import quizmodels.Quiz;
import quizmodels.User;

/**
 * Servlet implementation class Questions
 */
@WebServlet("/admin/questions")
public class Questions extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private QuestionDao questionDao = new QuestionDao();
	private QuizDao quizDao = new QuizDao();
	private AnswerDao answerDao = new AnswerDao();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Questions() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String event = request.getParameter("event");
		if (event != null) {
			switch (event) {
			case "getAnswers":
			case "getAnswersForEdit":
				String questionId = request.getParameter("questionId");
				List<Answer> answers = answerDao.getAnswersForQuestion(Integer.parseInt(questionId));
				for (Answer answer : answers) {
					answer.setQuestion(null);
				}
				response.getWriter().println(new Gson().toJson(answers));
				break;
			}
		} 
		else {
			User user = (User) request.getSession(false).getAttribute("user");
			List<Quiz> quizes = quizDao.getQuizes(user);
			request.setAttribute("quizes", quizes);
			request.setAttribute("questions", questionDao.getQuestions(user));
			request.getRequestDispatcher("/questions.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String questionId = request.getParameter("questionId");
		String event = request.getParameter("event");

		if (questionId != null) {
			if (event == null) {
				String questionText = request.getParameter("question");
				String time = request.getParameter("time");
				String pointForCorrectAnswer = request.getParameter("pointForCorrectAnswer");
				String quizId = request.getParameter("quiz");
				Quiz quiz = quizDao.getQuiz(Integer.parseInt(quizId));
				Question question = new Question();
				
				if (!questionId.equals("")) 
					question=questionDao.getQuestion(Integer.parseInt(questionId));			

				question.setQuestion(questionText);
				question.setTime(Integer.parseInt(time));
				question.setPointForCorrectAnswer(Integer.parseInt(pointForCorrectAnswer));
				question.setNumberOfQuestion(quiz.getQuestions().size() + 1);
				question.setQuiz(quiz);

				if (questionId.equals("")) {
					questionDao.save(question);
				}
				else {
					questionDao.update(question);
					answerDao.deleteAnswersForQuestion(Integer.parseInt(questionId));
				}
				String answerText;
				String isCorrect;

				for (int i = 1; i <= 4; i++) {
					Answer answer = new Answer();
					answerText = request.getParameter("answer" + i);

					if (!answerText.equals("")) {
						isCorrect = request.getParameter("isCorrectAnswer" + i);

						if (isCorrect != null) {
							answer.setCorrect(true);
						} else
							answer.setCorrect(false);

						answer.setAnswer(answerText);
						answer.setQuestion(question);
						answerDao.save(answer);
					}
				}
			} 
			else
				questionDao.remove(Integer.parseInt(questionId));
		}
		doGet(request, response);
	}
}
