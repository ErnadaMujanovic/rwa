package quizservlets;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import quizdao.RoleDao;
import quizdao.UserDao;
import quizmodels.User;
import quizutil.SecurityUtil;

/**
 * Servlet implementation class Users
 */
@WebServlet("/admin/users/*")
public class Users extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
	private static SecurityUtil securityUtil;
	private static RoleDao roleDao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Users() {
		super();
		userDao = new UserDao();
		securityUtil = new SecurityUtil();
		roleDao = new RoleDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	private void redirect(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect(request.getContextPath() + "/admin/users");
	}

	private void filterUsers(String column, String value){
//		users = userDao.filter(column, value);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (request.getPathInfo() != null) {
			if (request.getPathInfo().equals("/add"))
				request.getRequestDispatcher("/user-add.jsp").forward(request, response);
		} else
			request.getRequestDispatcher("/users.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		String p = request.getParameter("p");
		
		if (p != null) {
			if (p.equals("removeUser")) {
				String username = request.getParameter("username");
				userDao.remove(username);
			}
		} else {
			String firstName = request.getParameter("first-name");
			if (firstName != null) {
				String lastName = request.getParameter("last-name");
				String email = request.getParameter("email");
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				String repeatPassword = request.getParameter("repeat-password");
				String roleName = request.getParameter("role");

				if (password.equals(repeatPassword)) {
					userDao.save(new User(firstName, lastName, email, username, securityUtil.hashPassword(password),
							roleDao.getRoleByName(roleName)));
					redirect(request, response);
				}
			}

			String editFirstName = request.getParameter("edit-first-name");
			if (editFirstName != null) {
				String lastName = request.getParameter("edit-last-name");
				String email = request.getParameter("edit-email");
				String username = request.getParameter("edit-username");
				String oldUsername = request.getParameter("this-username");
				String password = request.getParameter("edit-password");
				String repeatPassword = request.getParameter("edit-repeat-password");
				String roleName = request.getParameter("edit-role");

				if (password.equals(repeatPassword)) {
					User user = userDao.find(oldUsername);
					String oldPassword = user.getPassword();
					userDao.remove(oldUsername);

					if (password.equals("------"))
						password = oldPassword;

					userDao.save(new User(editFirstName, lastName, email, username, securityUtil.hashPassword(password),
							roleDao.getRoleByName(roleName)));
					redirect(request, response);
				}
			}

			String searchUser = request.getParameter("search-user");
			if (searchUser != null) {
				String filter = request.getParameter("filter");
				filterUsers(filter, searchUser);
				redirect(request, response);
			}
		}
	}
}
