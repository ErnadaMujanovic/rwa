package quizservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import quizdao.AnswerDao;
import quizdao.InboxDao;
import quizdao.QuestionDao;
import quizdao.QuizDao;
import quizmodels.Answer;
import quizmodels.Person;
import quizmodels.Question;
import quizmodels.Quiz;

/**
 * Servlet implementation class playQuiz
 */
@WebServlet("/quiz/*")
public class playQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuizDao quizDao;
	private QuestionDao questionDao;
	private AnswerDao answerDao;
	private InboxDao inboxDao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public playQuiz() {
		super();
		quizDao = new QuizDao();
		questionDao = new QuestionDao();
		answerDao = new AnswerDao();
		inboxDao = new InboxDao();

		// TODO Auto-generated constructor stub
	}

	String getTwoQuizzes(HttpServletRequest request) {
		List<String> playedQuizzes = (List<String>) request.getSession().getAttribute("played-quizzes");
		if (playedQuizzes == null) {
			playedQuizzes = new ArrayList();
			request.getSession().setAttribute("played-quizzes", playedQuizzes);
		}
		playedQuizzes = (List<String>) request.getSession().getAttribute("played-quizzes");

		List<Integer> ids;
		Vector<Quiz> quizzes = new Vector<Quiz>();
		Random rand = new Random();
		Gson gson = new Gson();
		JsonObject quizzesJsonObject = new JsonObject();

		ids = quizDao.getIds(playedQuizzes);

		int index = rand.nextInt(ids.size());
		int id = ids.remove(index);
		quizzes.add(quizDao.getQuiz(id));

		index = rand.nextInt(ids.size());
		id = ids.remove(index);
		quizzes.add(quizDao.getQuiz(id));

		for (int i = 0; i < quizzes.size(); ++i) {
			Quiz quiz = quizzes.get(i);
			quiz.setUser(null);
			quiz.setQuestions(null);
			quiz.setResults(null);
		}

		String quizzesJson = gson.toJson(quizzes);
		return quizzesJson;
	}

	public static boolean isParsable(String input) {
		try {
			Integer.parseInt(input);
			return true;
		} catch (NumberFormatException | NullPointerException nfe) {
			return false;
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/playQuiz.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String path = request.getPathInfo();
		PrintWriter writer = response.getWriter();

		String p = request.getParameter("p");
		if (p == null) {
			if (path == null || path.equals("/")) {
				response.setContentType("text/plain");
				response.setCharacterEncoding("UTF-8");

				writer.println(getTwoQuizzes(request));
			} else {
				String idToParse = path.substring(1);

				if (isParsable(idToParse)) {
					int id = Integer.parseInt(path.substring(1));
					Quiz quiz = quizDao.getQuiz(id);
					if (quiz != null) {
						if (!quiz.isActive()) {
							writer.println("Quiz with id " + id + " is inactive!");
						} else {
							quiz.setUser(null);
							quiz.setQuestions(null);
							quiz.setResults(null);

							Gson gson = new Gson();
							String quizJson = gson.toJson(quiz);
							writer.println(quizJson);
						}
					} else {
						writer.println("There is no quiz with id " + id + "!");
					}
				} else {
					System.out.println("Not valid");
					writer.println("Id not valid!");
				}
			}

		} else if (p.equals("getQuestions")) {
			String quizId = request.getParameter("quizId");
			Vector<Question> questions = (Vector<Question>) questionDao.getQuestions(Integer.parseInt(quizId));
			Gson gson = new Gson();

			JsonObject questionsJsonObject = new JsonObject();

			for (int i = 0; i < questions.size(); ++i) {
				Question question = questions.get(i);
				question.setAnswers(null);
				question.setQuiz(null);

				String questionJson = gson.toJson(question);
				JsonObject questionJsonObject = new JsonParser().parse(questionJson).getAsJsonObject();

				Vector<Answer> answers = (Vector<Answer>) answerDao.getAnswersForQuestion(question.getId());
				JsonObject answersJsonObject = new JsonObject();

				for (int j = 0; j < answers.size(); ++j) {
					Answer answer = answers.get(j);
					answer.setQuestion(null);

					String answerJson = gson.toJson(answer);
					JsonObject answerJsonObject = new JsonParser().parse(answerJson).getAsJsonObject();
					answersJsonObject.add(Integer.toString(j), answerJsonObject);
				}

				questionJsonObject.add("answers", answersJsonObject);
				questionsJsonObject.add(Integer.toString(i), questionJsonObject);
			}

			String questionsJson = questionsJsonObject.toString();
			writer.println(questionsJson);
		} else if (p.equals("saveData")) {
			List<String> playedQuizzes = (List<String>) request.getSession().getAttribute("played-quizzes");

			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String email = request.getParameter("email");
			String points = request.getParameter("points");
			String quizId = request.getParameter("quizId");

			playedQuizzes.add(quizId);
			Person person = new Person();
			person.setFirstName(firstName);
			person.setLastName(lastName);
			person.setEmail(email);

			long totalPoints = quizDao.getTotalPoints(Integer.parseInt(quizId));
			inboxDao.saveResult(person, Integer.parseInt(points), Integer.parseInt(quizId));
			writer.println(totalPoints);
		}
	}
}
