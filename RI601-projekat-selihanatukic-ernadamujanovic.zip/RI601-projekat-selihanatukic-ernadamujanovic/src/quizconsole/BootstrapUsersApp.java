package quizconsole;

import java.util.ArrayList;
import java.util.List;

import quizdao.*;
import quizmodels.*;
import quizutil.SecurityUtil;

public class BootstrapUsersApp {
	private static SecurityUtil securityUtil = new SecurityUtil();
	private static UserDao userDao = new UserDao();
	private static RoleDao roleDao = new RoleDao();
	private static AnswerDao answerDao = new AnswerDao();
	private static QuizDao quizDao = new QuizDao();
	private static QuestionDao questionDao = new QuestionDao();
	private static InboxDao inboxDao = new InboxDao();

	static void addInitialRoles() {
		List<Role> roles = roleDao.getAllRoles();

		if (roles.size() == 0) {
			Role role = new Role("Super admin");
			roleDao.save(role);
			role = new Role("Editor");
			roleDao.save(role);
		}
	}

	static void addInitialUser() {
		List<User> users = userDao.getAllUsers();

		if (users.size() == 0) {
			User user = new User("Admin", "Admin", "admin.admin@gmail.ba", "admin", SecurityUtil.hashPassword("admin"),
					roleDao.getRoleByName("Super admin"));
			userDao.save(user);

			Person person = new Person("Editor", "Editor", "editor.editor@gmail.ba");
			user = new User(person, "editor", SecurityUtil.hashPassword("editor"), roleDao.getRoleByName("Editor"));
			userDao.save(user);
		}
	}

	static void addInitialQuizzes() {
		List<Inbox> inboxes = inboxDao.getAllInboxes(userDao.find("admin"));
		List<Answer> answers = answerDao.getAllAnswers();
		List<Question> questions = questionDao.getQuestions(userDao.find("admin"));
		List<Quiz> quizzes = quizDao.getActiveQuizzes();

		if (inboxes.size() != 0)
			inboxDao.deleteInboxes();
		if (answers.size() != 0)
			answerDao.deleteAnswers();
		if (questions.size() != 0)
			questionDao.deleteQuestions();
		if (quizzes.size() != 0)
			quizDao.deleteQuizzes();

		

		Quiz quiz = new Quiz("Java Servlets", "servlets.jpg", true, "This quiz tests your Servlets skills.",
				userDao.find("editor"));
		quizDao.save(quiz);

		Question question = new Question(
				"In which file do we define a servlet mapping ?", 20, 5,1, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("web.xml", true));
		answers.add(new Answer("servlet.mappings", false));
		answers.add(new Answer("servlet.xml", false));
		answers.add(new Answer("Simple.java", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Which methods do Servlet interface specifies?", 20, 5, 2, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("doGet()", false));
		answers.add(new Answer("doPost()", false));
		answers.add(new Answer("service()", true));
		answers.add(new Answer("init()", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("The session tracking in the JSP can be done by:", 20, 5, 3, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("URL rewriting", true));
		answers.add(new Answer("Hidden Files", true));
		answers.add(new Answer("Cookies", true));
		answers.add(new Answer("User-Authorization", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		

		question = new Question(" All servlets must implement the Servlet interface of package:", 15, 5, 4, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("javax.servlet", true));
		answers.add(new Answer(".servlet ", false));
		answers.add(new Answer("java.servlet ", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("A get request gets information from a client. A post request posts data to a client.", 20, 5, 5, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("True", false));
		answers.add(new Answer("False", true));
		answers.add(new Answer("Not always", false));
		answers.add(new Answer("None of these", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Which arguments does doFilter() take?", 25, 5, 6, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("FilterChain", true));	
		answers.add(new Answer("FilterConfig", false));
		answers.add(new Answer("ServletRequest", true));	
		answers.add(new Answer("HttpServletResponse", false));
		

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Which of the following can be used to store client side user state information while avoiding any impact due to the users web browser configuration ?", 20, 5, 7, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("HttpSessions ", true));
		answers.add(new Answer("Cookies ", false));
		answers.add(new Answer("Hidden tags", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Parameters are passed as _______ pairs in a get request.", 25, 5, 8, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("value ", false));
		answers.add(new Answer("Both can be used ", false));
		answers.add(new Answer("Non of these", false));		
		answers.add(new Answer("name/value", true));
		

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		question = new Question("Which types of objects can store attributes?", 30, 5, 9, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("ServletConfig", false));
		answers.add(new Answer("ServletContext", true));
		answers.add(new Answer("ServletResponse", false));
		answers.add(new Answer("HttpServletRequest", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		
		question = new Question("Which method returns the object of RequestDispatcher?", 20, 5, 10, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("getServletContext().getRequestDispatcher()", true));
		answers.add(new Answer("request.getServletContext().getRequestDispatcher()", false));
		answers.add(new Answer("request.getRequestDispatcher()", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		quiz = new Quiz("JavaScript", "js1.png", true, "This quiz tests your JavaScript skills.", userDao.find("admin"));
		quizDao.save(quiz);
		 question = new Question("Where is the correct place to insert a JavaScript?", 20, 5, 1, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Both the <head> section and the <body> section", true));
		answers.add(new Answer("The <head> section", false));
		answers.add(new Answer("The <body> section", false));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}


		question = new Question(" Can an anonymous function be assigned to a variable? ", 20, 5, 2, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Yes", true));
		answers.add(new Answer("No", false));
		

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("What is the correct syntax for referring to an external script called \"xxx.js\"?", 25, 5, 3, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("<script src=\"xxx.js\" >", true));
		answers.add(new Answer("<script name=\"xxx.js\"> ", false));
		answers.add(new Answer("<script href=\"xxx.js\"> ", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		question = new Question("How do we create a function in JavaScript?", 30, 5, 4, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("function = foo()", false));
		answers.add(new Answer("foo = function()", true));
		answers.add(new Answer("function foo()", true));
		answers.add(new Answer("function:foo()", false));		
		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		question = new Question("What do comparation operators return?", 15, 5, 5, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("True", true));
		answers.add(new Answer("False", true));
		answers.add(new Answer("Right", false));
		answers.add(new Answer("Wrong", false));		
		

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		question = new Question("Which is the correct way to write a comment in JavaScript?", 25, 5, 6, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer(" // ....", true));
		answers.add(new Answer("{# ... #}", true));
		answers.add(new Answer(" <!--- .... ---!>", false));
		answers.add(new Answer(" \\ ...", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		

		question = new Question(" What are the data types supported by JavaScript?", 30, 5, 7, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("double", false));
		answers.add(new Answer("Undefined",true));
		answers.add(new Answer("Object", true));
		answers.add(new Answer("String", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Can declared variable be deleted?", 15, 5, 8, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Yes", false));
		answers.add(new Answer("No", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Is JavaScript a case-sensitive language?", 15, 5, 9, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Yes", true));
		answers.add(new Answer("No", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Which of the following is a server-side Java Script object?", 20, 5, 10, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Function ", false));
		answers.add(new Answer("FileUpload ", false));
		answers.add(new Answer("File ", true));



		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		
		quiz = new Quiz("Quiz1", "quiz1.jpg", true, "This quiz is just an example of active quiz.", userDao.find("admin"));
		quizDao.save(quiz);

		question = new Question("Question 1?", 30, 5, 1, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 2?", 25, 5, 2, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", true));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 3?", 15, 5, 3, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 4?", 25, 5, 4, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 5?", 10, 5, 5, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 6?", 15, 5, 6, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", true));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 7?", 30, 5, 7, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 8?", 15, 5, 8, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 9?", 15, 5, 9, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", false));
		
		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 10?", 20, 5, 10, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
		
		quiz = new Quiz("Quiz2", "quiz2.png", false, "This quiz is just an example of inactive quiz.", userDao.find("admin"));
		quizDao.save(quiz);

		question = new Question("Question 1?", 30, 5, 1, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 2?", 25, 5, 2, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", false));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 3?", 15, 5, 3, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 4?", 25, 5, 4, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 5?", 10, 5, 5, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 6?", 15, 5, 6, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", false));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 7?", 30, 5, 7, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", true));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 8?", 15, 5, 8, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));
		answers.add(new Answer("Answer 4", false));

		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 9?", 15, 5, 9, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", true));
		answers.add(new Answer("Answer 2", false));
		answers.add(new Answer("Answer 3", false));
		answers.add(new Answer("Answer 4", true));
		
		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}

		question = new Question("Question 10?", 20, 5, 10, quiz);
		questionDao.save(question);

		answers = new ArrayList<Answer>();
		answers.add(new Answer("Answer 1", false));
		answers.add(new Answer("Answer 2", true));
		answers.add(new Answer("Answer 3", true));


		for (Answer a : answers) {
			a.setQuestion(question);
			answerDao.save(a);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addInitialRoles();
		addInitialUser();
		addInitialQuizzes();
	}
}
