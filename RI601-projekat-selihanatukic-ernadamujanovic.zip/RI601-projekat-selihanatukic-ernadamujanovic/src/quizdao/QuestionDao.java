package quizdao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import quizmodels.Question;
import quizmodels.User;

public class QuestionDao extends AbstractDao {
	private AnswerDao answerDao = new AnswerDao();

	public List<Question> getQuestions(User user) {
		EntityManager em = createEntityManager();
		try {
			Query q;
			if (user.getRole().getRoleName().equals("Editor"))
				q = em.createQuery("SELECT q FROM Question q WHERE q.quiz.user.id='" + user.getId() + "' ");
			else
				q = em.createQuery("SELECT q FROM Question q");

			List<Question> questions = q.getResultList();
			return questions;
		} catch (NoResultException e) {
			return new ArrayList<Question>();
		} finally {
			em.close();
		}
	}

	public Question getQuestion(int id) {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("SELECT q FROM Question q WHERE q.id='" + id + "'");
			Question question = (Question) q.getSingleResult();
			return question;
		} catch (NoResultException e) {
			return null;
		} finally {
			em.close();
		}
	}

	public List<Question> getQuestions(int quizId) {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery(
					"SELECT q FROM Question q WHERE q.quiz.id='" + quizId + "' ORDER BY q.numberOfQuestion");
			List<Question> questions = q.getResultList();
			return questions;
		} catch (NoResultException e) {
			return new ArrayList<Question>();
		} finally {
			em.close();
		}
	}

	public List<Question> getQuestionsByQuizId(int quizId) {
		EntityManager em = createEntityManager();

		try {
			Query q = em.createQuery("SELECT q FROM Question q where q.quiz.id = '" + quizId + "'");
			List<Question> questions = q.getResultList();
			return questions;
		} catch (NoResultException e) {
			return new ArrayList<Question>();
		} finally {
			em.close();
		}
	}

	public void remove(int id) {
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q1 = em.createQuery("DELETE FROM Answer a WHERE a.question.id='" + id + "'");
			q1.executeUpdate();
			Query q2 = em.createQuery("DELETE FROM Question q WHERE q.id='" + id + "'");
			q2.executeUpdate();
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}
	}
	
	public void deleteQuestions(){
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q = em.createQuery("DELETE FROM Question q");
			q.executeUpdate();
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}	
	}
}
