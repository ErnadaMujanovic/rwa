package quizdao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import quizmodels.Question;
import quizmodels.Quiz;
import quizmodels.User;

public class QuizDao extends AbstractDao {

	public List<Quiz> getQuizes(User user) {
		EntityManager em = createEntityManager();
		try {
			Query q;
			if (user.getRole().getRoleName().equals("Editor"))
				q = em.createQuery("SELECT q FROM Quiz q WHERE  q.user.id='" + user.getId() + "'");
			else
				q = em.createQuery("SELECT q FROM Quiz q ");

			List<Quiz> quizes = q.getResultList();
			return quizes;
		} catch (NoResultException e) {
			return new ArrayList<Quiz>();
		} finally {
			em.close();
		}
	}

	public Quiz getQuiz(int id) {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("SELECT q FROM Quiz q WHERE  q.id='" + id + "'");
			Quiz quiz = (Quiz) q.getSingleResult();
			return quiz;
		} catch (NoResultException e) {
			return null;
		} finally {
			em.close();
		}
	}

	public void remove(int id) {
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q1 = em.createQuery("DELETE FROM Inbox i WHERE i.quiz.id='" + id + "'");
			q1.executeUpdate();
			Query q2 = em.createQuery("DELETE FROM Answer a WHERE a.question.quiz.id='" + id + "'");
			q2.executeUpdate();

			Query q3 = em.createQuery("DELETE FROM Question q WHERE q.quiz.id='" + id + "'");
			q3.executeUpdate();

			Query q4 = em.createQuery("DELETE FROM Quiz q WHERE q.id='" + id + "'");
			q4.executeUpdate();
			em.getTransaction().commit();

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}
	}

	public int size() {
		EntityManager em = createEntityManager();
		Query q = em.createQuery("SELECT COUNT(q.headline) FROM Quiz q");
		long size = (long) q.getSingleResult();
		return (int) size;
	}

	public Quiz find(int id, String headline) {
		EntityManager em = createEntityManager();
		try {
			Query q = em
					.createQuery("SELECT q FROM Quiz q WHERE q.headline = '" + headline + "' and q.id<> '" + id + "'");
			Quiz quiz = (Quiz) q.getSingleResult();
			return quiz;
		} catch (Exception e) {
			return null;
		} finally {
			em.close();
		}
	}

	public List<Integer> getIds(List<String> s) {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("SELECT q FROM Quiz q WHERE q.isActive = true");
			List<Quiz> quiz = q.getResultList();
			List<Integer> qq = (List<Integer>) quiz.stream().filter(e -> !s.contains(Integer.toString(e.getId())))
					.map(e -> e.getId()).collect(Collectors.toList());
			return qq;
		} catch (NoResultException e) {
			return new ArrayList<Integer>();
		} finally {
			em.close();
		}
	}

	public List<Quiz> getActiveQuizzes() {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("SELECT q FROM Quiz q WHERE q.isActive = true");

			return (List<Quiz>) q.getResultList();
		} catch (NoResultException e) {
			return new ArrayList<Quiz>();
		} finally {
			em.close();
		}
	}

	public long getTotalPoints(int id) {
		EntityManager em = createEntityManager();
		try {
			Query q;
			q = em.createQuery("SELECT SUM(question.pointForCorrectAnswer) FROM Question question INNER JOIN Quiz q "
					+ "ON question.quiz.id=q.id WHERE  q.id='" + id + "'");

			long num = (long) q.getSingleResult();
			System.out.println("num" + num);
			return num;
		} catch (NoResultException e) {
			return -1;
		} finally {
			em.close();
		}
	}

	public void deleteQuizzes() {
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q = em.createQuery("DELETE FROM Quiz q");
			q.executeUpdate();
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}
	}
}
