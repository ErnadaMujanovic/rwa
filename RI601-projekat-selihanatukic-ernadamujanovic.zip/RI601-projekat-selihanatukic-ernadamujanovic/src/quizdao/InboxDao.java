package quizdao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import quizmodels.Inbox;
import quizmodels.Person;
import quizmodels.Player;
import quizmodels.Quiz;
import quizmodels.User;

public class InboxDao extends AbstractDao {
	public List<Inbox> getAllInboxes(User user) {
		EntityManager em = createEntityManager();
		try {
			Query q;
			if (user.getRole().getRoleName().equals("Editor"))
				q = em.createQuery("SELECT i FROM Inbox i WHERE i.quiz.user.id='" + user.getId() + "'");
			else
				q = em.createQuery("SELECT i FROM Inbox i");

			List<Inbox> all = q.getResultList();
			return all;
		} catch (Exception e) {
			return new ArrayList<Inbox>();
		} finally {
			em.close();
		}
	}

	public Inbox getInboxByQuizId(int quizId) {
		EntityManager em = createEntityManager();
		try {
			Query q = em.createQuery("SELECT i FROM Inbox WHERE i.quiz_id = '" + quizId + "'");
			Inbox inbox = (Inbox) q.getSingleResult();
			return inbox;
		} catch (Exception e) {
			return null;
		} finally {
			em.close();
		}
	}

	public void saveResult(Person person, int points, int quizId) {
		EntityManager em = createEntityManager();
		try {
			AbstractDao dao = new AbstractDao();
			QuizDao quizDao = new QuizDao();

			Player player = new Player();
			player.setPerson(person);
			dao.save(player);

			Inbox result = new Inbox();
			result.setPlayer(player);
			result.setScore(points);
			Quiz quiz = quizDao.getQuiz(quizId);
			result.setQuiz(quiz);
			save(result);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}
	}

	public void deleteInboxes() {
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q = em.createQuery("DELETE FROM Inbox i");
			q.executeUpdate();
			em.getTransaction().commit();

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}
	}
}
