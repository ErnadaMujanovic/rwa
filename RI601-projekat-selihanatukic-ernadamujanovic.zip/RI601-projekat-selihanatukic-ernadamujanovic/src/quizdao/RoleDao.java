package quizdao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import quizmodels.Role;

public class RoleDao extends AbstractDao {

	public List<Role> getAllRoles(){
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT r FROM Role r");
		List<Role> all = q.getResultList();
		return all;
		} catch(Exception e) {
		  return new ArrayList<Role>();
		} finally {
		em.close();
		}
	}

	public Role getRoleByName(String name) {
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT r FROM Role r WHERE r.roleName='"+name+"'");
		Role role= (Role) q.getSingleResult();
		return role;
		} catch(Exception e) {
		  return null;
		} finally {
		em.close();
		}
	}
	
	public void deleteRoles(){
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
   			Query q = em.createQuery("DELETE FROM Role r");
			q.executeUpdate();
			em.getTransaction().commit();

			} catch(Exception e) {
			  System.out.println(e);
			} finally {
			em.close();
			}
	}
}
