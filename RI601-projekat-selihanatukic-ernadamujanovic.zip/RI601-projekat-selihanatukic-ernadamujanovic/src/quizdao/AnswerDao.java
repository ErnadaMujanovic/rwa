package quizdao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import quizmodels.Answer;


public class AnswerDao  extends AbstractDao{

	public List<Answer> getAllAnswers() {
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT a FROM Answer a");
		List<Answer> answers = q.getResultList();
		return answers;
		} catch(Exception e) {
		  return new ArrayList<Answer>();
		} finally {
		em.close();
		}
	}
	
	public List<Answer> getAnswersForQuestion(int questionId) {
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT a FROM Answer a WHERE a.question.id='"+questionId+"'");
		List<Answer> answers = q.getResultList();
		return answers;
		} catch(Exception e) {
		  return new ArrayList<Answer>();
		} finally {
		em.close();
		}
	}

	public void deleteAnswersForQuestion(int questionId) {
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
   			Query q = em.createQuery("DELETE FROM Answer a WHERE a.question.id='"+questionId+"'");
			q.executeUpdate();
			em.getTransaction().commit();

			} catch(Exception e) {
			  System.out.println(e);
			} finally {
			em.close();
			}
    }
	
	public void deleteAnswers(){
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
   			Query q = em.createQuery("DELETE FROM Answer a");
			q.executeUpdate();
			em.getTransaction().commit();

			} catch(Exception e) {
			  System.out.println(e);
			} finally {
			em.close();
			}
	}
	
}
