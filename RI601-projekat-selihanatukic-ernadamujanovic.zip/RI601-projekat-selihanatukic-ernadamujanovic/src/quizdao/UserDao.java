package quizdao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import quizmodels.Role;
import quizmodels.User;
import quizutil.SecurityUtil;

public class UserDao extends AbstractDao{
	
	private static SecurityUtil securityUtil = new SecurityUtil();

	public List<User> getAllUsers(){
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT u FROM User u");
		List<User> all = q.getResultList();
		return all;
		} catch(Exception e) {
		  return new ArrayList<User>();
		} finally {
		em.close();
		}
	}
	
	public User find(String username) {
		EntityManager em = createEntityManager();
		try {
		Query q = em.createQuery("SELECT u FROM User u WHERE u.username = '" + username + "'");
		User user = (User) q.getSingleResult();
		return user;
		} catch(Exception e) {
		  return null;
		} finally {
		em.close();
		}
	}
	
	public User authenticate(String username, String password) {
		User user = find(username);

		if (user == null) {
			return null;
		}

		if (SecurityUtil.checkPassword(password, user.getPassword())){
			return user;
		}
		return null;
	}
	
	public void remove(String username) {
		int personId = find(username).getPerson().getId();
		EntityManager em = createEntityManager();
		em.getTransaction().begin();
		
		Query q1 = em.createQuery("DELETE FROM User u WHERE u.username = '" + username + "'");
		q1.executeUpdate();
		
		Query q2 = em.createQuery("DELETE FROM Person p WHERE p.id = '" + personId + "'");
		q2.executeUpdate();
	
		em.getTransaction().commit();
		em.close();
	}
	
	public List<User> filter(String column, String value){
		return getAllUsers();
	}
	
	public void deleteUsers(){
		EntityManager em = createEntityManager();
		try {
			em.getTransaction().begin();
			Query q1 = em.createQuery("DELETE FROM User u");
			q1.executeUpdate();
			
			Query q2 = em.createQuery("DELETE FROM Person p");
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			em.close();
		}	
	}
}

