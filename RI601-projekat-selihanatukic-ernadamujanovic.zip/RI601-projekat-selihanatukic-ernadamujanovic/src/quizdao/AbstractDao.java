package quizdao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import quizmodels.Question;

public class AbstractDao {
	private static final String PERSISTENCE_UNIT_NAME = "RI601-projekat-selihanatukic-ernadamujanovic";

	public EntityManager createEntityManager() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		return emf.createEntityManager();
	}

	public void save(Object e) {
		EntityManager em = createEntityManager();
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		em.close();	
	}
	
	public void update(Object obj) {
		
		 EntityManager em = createEntityManager();
		 try {
				em.getTransaction().begin();
				em.merge(obj);
				em.getTransaction().commit();

		 }catch(Exception e) {
	      System.out.println(e.getMessage());
	      }finally {
			em.close();
			}
	}
	
}
