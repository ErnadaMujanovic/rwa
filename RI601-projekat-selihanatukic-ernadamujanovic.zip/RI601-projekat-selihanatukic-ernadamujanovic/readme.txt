GIFOVI
1.Admin:  https://drive.google.com/file/d/14Uz8QebJ8gNt5Wp71WZoKcgz67eNQhIq/view?usp=sharing
2.Igranje kvizova:  https://drive.google.com/file/d/1uC8NdQCNxd3AYBXhEMEUC0RTHcWqmkFY/view?usp=sharing
3.Editor:  https://drive.google.com/file/d/1D-qBoSkYZlxsaBh91Ynh3SqAItZ8cRfU/view?usp=sharing

NEIMPLEMENTIRANE STAVKE


1.Izmjena redoslijeda pitanja u kvizovima.
2.Nije prikazano brojno stanje korisnika koji trenutno igraju neki od kvizova.
