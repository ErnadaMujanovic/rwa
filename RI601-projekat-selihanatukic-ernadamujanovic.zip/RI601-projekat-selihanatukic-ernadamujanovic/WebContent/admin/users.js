$(document).ready(function() {
	$(".edit-btn").click(function(button) {
		var tr = $(this).closest('tr');
		var firstName = tr.find("td:eq(0)")[0].innerText;
		var lastName = tr.find("td:eq(1)")[0].innerText;
		var email = tr.find("td:eq(2)")[0].innerText;
		var username = tr.find("td:eq(3)")[0].innerText;
		var role = tr.find("td:eq(4)")[0].innerText;
		
		openEditUserModal(firstName, lastName, email, username, role);
	})

	$(".delete-btn").click(function() {
		var answer = confirm("Delete user?");
		if (answer) {
			var tr = $(this).closest('tr');
			var username = tr.find("td:eq(3)")[0].innerText;
			var params = {
				p : "removeUser",
				username : username
			};
			$.post("../admin/users/*", $.param(params), function(response) {
			});

			tr.remove();
		}
	})

	$("#search-btn").click(function() {
		var selected = $("#filter option:selected").text();
		var searchedValue = $("#search-input")[0].value;
		var table = document.getElementById("users-table");
		var tableHeaders = table.getElementsByTagName('th');
		var tableRows = table.rows;

		for (var j = 1; j < tableRows.length; ++j) {
			tableRows[j].style.display = "table-row";
		}

		if (selected != "Select filter" && searchedValue != "") {
			var column;

			for (var i = 0; i < tableHeaders.length; ++i) {
				if (tableHeaders[i].innerText == selected)
					column = i;
			}

			for (var j = 1; j < tableRows.length; ++j) {
				var td = tableRows[j].getElementsByTagName('td');
				var columnValue = td[column].innerText;
				columnValue = columnValue.toLowerCase();
				if (!columnValue.startsWith(searchedValue.toLowerCase())) {
					tableRows[j].style.display = "none";
				}
			}
		}
	})

	$("#search-button").click(function() {
		displayInline("search-input");
		displayInline("filter");
		displayInline("search-btn");
		displayInline("back-btn");

		displayNone("search-button");
	})

	$("#back-btn").click(function() {
		document.getElementById("search-input").value = "";
		document.getElementById("filter").value = "";
		displayNone("search-input");
		displayNone("filter");
		displayNone("search-btn");
		displayNone("back-btn");

		displayInline("search-button");
	})
});