function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayInline(id) {
	document.getElementById(id).style.display = "inline";
}

$(document).ready(function() {
	
	$(".edit-btn").click(function() {
    	var tr = ($(this).closest('tr'));
    	var headline = tr.find("td:eq(0)")[0].innerText;
    	var fullPathImage= tr.find("td:eq(1)")[0].firstElementChild.getAttribute('src');
		var dir = "/RI601-projekat-selihanatukic-ernadamujanovic/images/";
		var imageName = fullPathImage.substring(dir.length,fullPathImage.length);
		console.log(imageName)
		var description = tr.find("td:eq(2)")[0].innerText;
		var isActive = tr.find("td:eq(3)")[0].firstElementChild.checked;
	    var quizId= tr.find("td:eq(4)")[0].firstElementChild.getAttribute('value');
		populateQuizesModal(headline,imageName,description,isActive,quizId);
	    
    	});
	
	$(".questions-btn").click(function() {
    	var tr = ($(this).closest('tr'));
   	    var id= tr.context.value;
   	    
	   	 var params = {
					event : "getQuestions",
					quizId : id
				};
	   	 $.get("../admin/quizes/*", $.param(params), function(response) {
		    	console.log(response);
		    	populateQuestionsModal(response);
					});
    	});
	

});

function orderQuestions(){
	var questionDivs = document.getElementById("questions").children;
	var questions = new Array();
	for(var i = 0;i < questionDivs.length;i++)
		questions.push(questionDivs[i].firstElementChild.value);

     var params = {
			event : "orderQuestions",
			questions : questions
			};
     $.post("../admin/quizes", $.param(params), function(response) {
	       closeQuestionModal();
		 });
}


function deleteQuiz(quizId, e){
	  var params = {
				event : "deleteQuiz",
				quizId : quizId
			};
	 $.post("../admin/quizes", $.param(params), function(response) {
		 var tableRow = $("td:nth-child(6)").filter(function() {
			 return this.firstElementChild.value == quizId;
			 }).closest('tr')
			 tableRow.remove();
		 closeQuizDeleteModal();
		   
	});
}



$("#search-btn").click(function() {
	var searchedValue = $("#search-input")[0].value;
	var active = $("#cb-active")[0].checked;
	var inactive = $("#cb-inactive")[0].checked;
	var table = document.getElementById("quizes-table");
	var tableHeaders = table.getElementsByTagName('th');
	var tableRows = table.rows;

	for (var j = 1; j < tableRows.length; ++j) {
		tableRows[j].style.display = "table-row";
	}

	for (var j = 1; j < tableRows.length; ++j) {
		var td = tableRows[j].getElementsByTagName('td');
		var columnValue;
		var isActive = $(td[3].innerHTML)[0].checked;

		if (searchedValue != "") {
			columnValue = td[0].innerText;
			columnValue = columnValue.toLowerCase();
			if (!columnValue.startsWith(searchedValue.toLowerCase()))
				tableRows[j].style.display = "none";
		}
		if((!active && ((!inactive && isActive) || (inactive && isActive) || (!inactive && !isActive))) || (active && !inactive && !isActive)){
			tableRows[j].style.display = "none";
		}
	}
})

$("#search-button").click(function() {
	displayInline("search-input");
	displayInline("search-btn");
	displayInline("back-btn");
	displayInline("checkbox-active");
	displayInline("checkbox-inactive");
	displayNone("search-button");
})

$("#back-btn").click(function() {
	document.getElementById("search-input").value = "";
	displayNone("search-input");
	displayNone("search-btn");
	displayNone("back-btn");
	displayNone("checkbox-active");
	displayNone("checkbox-inactive");
	displayInline("search-button");



})



function submitFunction() {
	var headline = document.getElementById("headline").value;

	var params = {
			headline : headline
	};

	$.post("../admin/quizes/*", $.param(params), function(response) {
		var notValidLabel = document.getElementById("not-valid");
		if (response == "Quiz with this headline already exists!") {
			notValidLabel.innerText = response;
			$("#not-valid").fadeIn();
			setTimeout(function() {
				$("#not-valid").fadeOut();
			}, 1500);
		} else
			document.getElementById("quiz-form").submit();
	});
}