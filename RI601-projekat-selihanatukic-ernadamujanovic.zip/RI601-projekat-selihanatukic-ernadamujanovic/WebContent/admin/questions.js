function displayInline(id) {
	document.getElementById(id).style.display = "inline";
}

$(document)
		.ready(
				function() {
					$(".answer-btn").click(function() {
						var tr = ($(this).closest('tr'));
						var id = tr.context.value;
						var params = {
							event : "getAnswers",
							questionId : id
						};
						getAnswers(params)
					})

					function getAnswers(params) {
						$.get("../admin/questions", $.param(params), function(
								response) {
							switch (params.event) {
							case "getAnswersForEdit":
								populateQuestionAnswers(response);
								break;
							case "getAnswers":
								openAnswersModal(response);
								break;
							}
						});
					}

					$(".edit-btn")
							.click(
									function() {
										var tr = ($(this).closest('tr'));
										var questionText = tr.find("td:eq(0)")[0].innerText;
										var questionId = tr.find("td:eq(5)")[0].value;
										var quizId = tr.find("td:eq(1)")[0]
												.getAttribute('value');
										var time = tr.find("td:eq(2)")[0].innerText;
										var pointForCorrectAnswer = tr
												.find("td:eq(3)")[0].innerText;
										var id = tr.context.value;
										populateQuestionsModal(id,
												questionText, quizId, time,
												pointForCorrectAnswer)

										var params = {
											event : "getAnswersForEdit",
											questionId : id
										};
										getAnswers(params);
									});

					$("#search-btn")
							.click(
									function() {
										var selected = $(
												"#filter option:selected")
												.text();
										var searchedValue = $("#search-input")[0].value;
										var table = document
												.getElementById("questions-table");
										var tbHeaders = table
												.getElementsByTagName('th');
										var tbRows = table.rows;

										for (var j = 1; j < tbRows.length; ++j) {
											tbRows[j].style.display = "table-row";
										}

										if (selected != "Select filter"
												&& searchedValue != "") {
											var column;

											for (var i = 0; i < tbHeaders.length; ++i) {
												if (tbHeaders[i].innerText == selected)
													column = i;
											}
											for (var j = 1; j < tbRows.length; ++j) {
												var td = tbRows[j]
														.getElementsByTagName('td');
												var columnValue = td[column].innerText;
												columnValue = columnValue
														.toLowerCase();
												if (!columnValue
														.startsWith(searchedValue
																.toLowerCase())) {
													tbRows[j].style.display = "none";
												}
											}
										}
									})

					$("#search-button").click(function() {
						displayInline("search-input");
						displayInline("filter");
						displayInline("search-btn");
						displayInline("back-btn");

						displayNone("search-button");
					})

					$("#back-btn").click(function() {
						document.getElementById("search-input").value = "";
						document.getElementById("filter").value = "";
						displayNone("search-input");
						displayNone("filter");
						displayNone("search-btn");
						displayNone("back-btn");

						displayInline("search-button");
					})
			
				});

function deleteQuestion(questionId) {
	var params = {
		event : "deleteQuestion",
		questionId : questionId
	};
	$.post("../admin/questions", $.param(params), function(response) {
		 var tbRow = $("td:nth-child(6)").filter(function() {
			 return this.firstElementChild.value == questionId;
			 }).closest('tr')
			 tbRow.remove();
		 closeQuestionDeleteModal();
	});

}