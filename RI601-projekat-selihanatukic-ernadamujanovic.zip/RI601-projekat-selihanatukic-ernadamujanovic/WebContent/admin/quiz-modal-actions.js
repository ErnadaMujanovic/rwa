function setModalTitle(title){
	document.getElementById("quiz-title").innerHTML= title;
}

function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayBlock(id) {
	document.getElementById(id).style.display = "block";
}

function openQuizModal(id){
	if(id==undefined)
		setModalTitle("Add quiz");
	else{
		document.getElementById("upload").required=false;
		setModalTitle("Edit quiz");
	}
	document.getElementById("upload").addEventListener("change",function (){
	document.getElementById("uploadInput").value=this.files[0].name;     
	})
   displayBlock("modal-quiz");
}

function closeQuizModal() {
	displayNone("modal-quiz");
	resetQuizModal();
}

function closeQuizDeleteModal(){
	displayNone("delete-quiz-modal");
}

function openQuizDeleteModal(id){
	document.getElementById("delete-btn").value=id;
	displayBlock("delete-quiz-modal");
}

function openQuestionModal(){
	displayBlock("modal-questions");
}

function closeQuestionModal(){
	document.getElementById("questions").innerHTML="";
	displayNone("modal-questions");

}


	
function resetQuizModal(){
	document.getElementById("quizId").value = "";
	document.getElementById("headline").value = "";
	document.getElementById("description").value = "";
	document.getElementById("active").checked = false;
	document.getElementById("uploadInput").value = "";
	document.getElementById("upload").required=true;

}

function populateQuizesModal(headline,imageName,description,isActive,quizId){
	document.getElementById("quizId").value = quizId;
	document.getElementById("headline").value = headline;
	document.getElementById("description").value =description;
	document.getElementById("active").checked = isActive;
	document.getElementById("uploadInput").value = imageName;
 	openQuizModal(quizId);
}


function populateQuestionsModal(questions){
	var list=document.getElementById("questions");
	questions=JSON.parse(questions);
		for(var i = 0;i < questions.length; i++)
	{
		var div = document.getElementById("quiz-div").cloneNode(true);
		 div.lastElementChild.innerHTML=questions[i].question;
		 div.firstElementChild.value=questions[i].id;

		 div.style.display="block";
		 list.appendChild(div);
	}
	openQuestionModal();
}