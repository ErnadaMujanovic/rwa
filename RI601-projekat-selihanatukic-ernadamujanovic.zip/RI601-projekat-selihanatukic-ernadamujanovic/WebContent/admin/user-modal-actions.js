function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayBlock(id) {
	document.getElementById(id).style.display = "block";
}

function displayInline(id) {
	document.getElementById(id).style.display = "inline";
}

function enableSubmit(id) {
	document.getElementById(id).disabled = false;
}

function disableSubmit(id) {
	document.getElementById(id).disabled = true;
}

function correct(blockId, submitId) {
	enableSubmit(submitId);
}

function error(blockId, submitId, innerText) {
	$("#" + blockId)[0].innerText = innerText;
	$("#" + blockId).fadeIn();
	disableSubmit(submitId);
	setTimeout(function() {
		$("#" + blockId).fadeOut();
	}, 2000);
}

function closeAddUserModal() {
	displayNone("modal-add-user");
	document.getElementById("first-name").value = "";
	document.getElementById("last-name").value = "";
	document.getElementById("email").value = "";
	document.getElementById("username").value = "";
	document.getElementById("role").value = "";
	document.getElementById("password").value = "";
	document.getElementById("repeat-password").value = "";
}

function openEditUserModal(firstName, lastName, email, username, role) {
	document.getElementById("edit-first-name").value = firstName;
	document.getElementById("edit-last-name").value = lastName;
	document.getElementById("edit-email").value = email;
	document.getElementById("edit-username").value = username;
	document.getElementById("this-username").value = username;
	document.getElementById("edit-role").value = role;
	document.getElementById("edit-password").value = "------";
	document.getElementById("edit-repeat-password").value = "------";

	displayBlock("modal-edit-user");
}

function closeEditUserModal() {
	displayNone("modal-edit-user");
}

function checkUsername() {
	var username = document.getElementById("username").value;
	var table = document.getElementById("users-table");
	var n = table.rows.length;
	if (username != "") {
		for (var r = 1; r < n; r++) {
			console.log(table.rows[r].cells)
			if (table.rows[r].cells[3].innerText == username) {
				error("add-error", "add-user-submit",
						"Username already exists!");
			}
		}
	} else {
		var editUsername = document.getElementById("edit-username").value;
		for (var i = 1; i < n; i++) {
			console.log(document.getElementById("this-username").value)
			if (table.rows[i].cells[3].innerText == editUsername
					&& document.getElementById("this-username").value != editUsername) {
				error("edit-error", "edit-user-submit",
						"Username already exists!");
			}
		}
	}
}

function checkPasswords() {
	var password = document.getElementById("password").value;
	var repeatPassword = document.getElementById("repeat-password").value;
	if (password != "" && repeatPassword != "") {
		if (password != repeatPassword) {
			error("add-error", "add-user-submit", "Passwords are not same!");
		}
	} else {
		var editPassword = document.getElementById("edit-password").value;
		var editRepeatPassword = document
				.getElementById("edit-repeat-password").value;
		if (editPassword != "" && editRepeatPassword) {
			if (editPassword != editRepeatPassword) {
				error("edit-error", "edit-user-submit",
						"Passwords are not same!");
			}
		}
	}
}