function setModalTitle(title){
	document.getElementById("question-title").innerHTML= title;
}

function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayBlock(id) {
	document.getElementById(id).style.display = "block";
}

function openQuestionModal(id){
	if(id==undefined)
		setModalTitle("Add question");
	else
		setModalTitle("Edit question");
	displayBlock("modal-question");
}

function closeQuestionModal(){
	displayNone("modal-question");
	resetQuestionForm();
}
function openQuestionDeleteModal(id){
	document.getElementById("delete-btn").value=id;
	displayBlock("delete-question-modal");
}

function closeQuestionDeleteModal(){
	displayNone("delete-question-modal");
}
function resetQuestionForm(){
	
	document.getElementById("questionId").value="";
	document.getElementById("questionText").value="";
	document.getElementById("quiz").value="";
	document.getElementById("time").value="";
	document.getElementById("pointForCorrectAnswer").value="";
	
	document.getElementById("answer1").value="";
	document.getElementById("isCorrectAnswer1").checked = false;
	document.getElementById("answer2").value="";
	document.getElementById("isCorrectAnswer2").checked = false;
	document.getElementById("answer3").value="";
	document.getElementById("isCorrectAnswer3").checked = false;
	document.getElementById("answer4").value="";
	document.getElementById("isCorrectAnswer4").checked = false;
	
}


function populateQuestionsModal(questionId,questionText,quizId,time,pointForCorrectAnswer){
	document.getElementById("questionId").value=questionId;
	document.getElementById("questionText").value=questionText;
	document.getElementById("time").value=time;
	document.getElementById("pointForCorrectAnswer").value=pointForCorrectAnswer;
	document.getElementById("quiz").value=quizId;	
	openQuestionModal(questionId)
}

function populateAnswersModal(answers){
	var list=document.getElementById("answersList");
	
	for(var i = 0;i < answers.length; i++)
	{
	 var li = document.createElement("li");
	 var div=document.createElement("div");
	 div.setAttribute("style","display:flex;flex-direction:row");
	 var answer = document.createElement("p");
	 answer.innerHTML=answers[i].answer;
	 answer.setAttribute("style","margin-left: 10px;");
	 var icon= document.createElement("i");
	
	 if(answers[i].isCorrect==true)
	 {
		 icon.classList.add("fa","fa-check");
		 icon.setAttribute("style","color:green");
	 }
	 else{
		 icon.classList.add("fas","fa-times");	
		 icon.setAttribute("style","color:red");
	 }
	 div.appendChild(icon);
	 div.appendChild(answer);
	 li.appendChild(div);
	 list.appendChild(li);

	}
}

function populateQuestionAnswers(answers){
	var list=JSON.parse(answers);
	for(var i = 0;i < list.length; i++){
		var j=i+1;
		document.getElementById("answer"+j).value=list[i].answer;
		document.getElementById("isCorrectAnswer"+j).checked =list[i].isCorrect;
		document.getElementById("isCorrectAnswer"+j).disabled=false;
	}
}
function openAnswersModal(answers){
	var list=JSON.parse(answers);
	populateAnswersModal(list);
	displayBlock("modal-answers");
}

function closeAnswersModal(){
	displayNone("modal-answers");
	resetAnswersModal();
}
function resetAnswersModal(){
	var list=document.getElementById("answersList");
	list.innerHTML="";
}



function inputTyped(check, e){
	var checkbox = document.getElementById(check);
    if(e.value.length > 0){
    	checkbox.disabled=false;
    }
    else{
    	checkbox.checked = false;
    	checkbox.disabled=true;
    }
 }