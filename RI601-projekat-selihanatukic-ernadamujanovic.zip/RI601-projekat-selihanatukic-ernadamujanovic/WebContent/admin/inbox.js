function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayInline(id) {
	document.getElementById(id).style.display = "inline";
}

$(document).ready(function() {
	$("#search-btn").click(function() {
		var selected = $("#filter option:selected").text();
		var searched = $("#search-input")[0].value;
		var table = document.getElementById("inbox-table");
		var tbHeaders = table.getElementsByTagName('th');
		var tbRows = table.rows;
	
		for (var j = 1; j < tbRows.length; ++j) {
			tbRows[j].style.display = "table-row";
		}

		if (selected != "Select filter" && searched != "") {
			var column;

			for (var i = 0; i < tbHeaders.length; ++i) {
				if (tbHeaders[i].innerText == selected)
					column = i;
			}

			for (var j = 1; j < tbRows.length; ++j) {
				var td = tbRows[j].getElementsByTagName('td');
				var columnValue = td[column].innerText;
				columnValue = columnValue.toLowerCase();
				if (!columnValue.startsWith(searchedValue.toLowerCase())) {
					tbRows[j].style.display = "none";
				}
			}
		}
	})

	$("#search-button").click(function() {
		displayInline("search-input");
		displayInline("filter");
		displayInline("search-btn");
		displayInline("back-btn");
		displayNone("search-button");
	})

	$("#back-btn").click(function() {
		document.getElementById("search-input").value = "";
		document.getElementById("filter").value = "";
		displayNone("search-input");
		displayNone("filter");
		displayNone("search-btn");
		displayNone("back-btn");

		displayInline("search-button");
	})
	
	
	
		
	$(".export").click(function(){
		let csvContent = "data:text/csv;charset=utf-8,";

		var rows = $('#inbox-table tr');

		$.each(rows,function(index,value){
		var array = $.map(value.children,function(n,i){return n.innerHTML});
		var tmp = array.join(",");
		    csvContent += tmp + "\r\n";
		});

		var encodedUri = encodeURI(csvContent);
		var link = document.createElement("a");
		link.setAttribute("href", encodedUri);
		link.setAttribute("download", "inbox.csv");
		document.body.appendChild(link); 
		link.click(); 
		
		});
});