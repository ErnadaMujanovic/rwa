function submitFunction() {
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;

	var params = {
		username : username,
		password : password
	};

	$.post("login", $.param(params), function(response) {
		var notValidLabel = document.getElementById("not-valid");
		if (response == "Username or password not valid!") {
			notValidLabel.innerText = response;
			$("#not-valid").fadeIn();
			setTimeout(function() {
				$("#not-valid").fadeOut();
			}, 1500);
		} else
			document.getElementById("login-form").submit();
	});
}