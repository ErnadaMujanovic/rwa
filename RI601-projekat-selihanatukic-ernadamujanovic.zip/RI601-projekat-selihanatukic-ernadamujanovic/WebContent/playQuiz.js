function displayNone(id) {
	document.getElementById(id).style.display = "none";
}

function displayBlock(id) {
	document.getElementById(id).style.display = "block";
}

$(document)
		.ready(
				function() {
					var pathname = location.pathname;
					quiz = pathname.substr(8, pathname.length);
					$
							.post(
									pathname,
									function(responseText) {
										if (responseText.length != 0) {
											if (responseText
													.startsWith("There is no")
													|| responseText
															.startsWith("Id not valid")
													|| responseText
															.startsWith("Quiz with")) {
												displayBlock("quiz-div-1");
												displayNone("quiz-div-2");
												document
														.getElementById("quiz-div-1").innerHTML = "<h1 style='text-align: center;'>"
														+ responseText + "<h1>";
											} else {
												var obj = JSON
														.parse(responseText);

												if (obj[1] == undefined) {
													displayBlock("quiz-div-1");
													displayNone("quiz-div-2");
													document
															.getElementById("quiz1-icon").src = "/project/images/"
															+ obj.icon;
													document
															.getElementById("real-quiz1-id").innerText = obj.id;
													document
															.getElementById("quiz1-title").innerText = obj.headline;
													document
															.getElementById("quiz1-description").innerText = obj.description;
												} else {
													displayBlock("quiz-div-1");
													displayBlock("quiz-div-2");
													document
															.getElementById("quiz1-icon").src = "/RI601-projekat-selihanatukic-ernadamujanovic/images/"
															+ obj[0].icon;
													document
															.getElementById("quiz2-icon").src = "/RI601-projekat-selihanatukic-ernadamujanovic/images/"
															+ obj[1].icon;
													document
															.getElementById("real-quiz1-id").innerText = obj[0].id;
													document
															.getElementById("quiz1-title").innerText = obj[0].headline;
													document
															.getElementById("quiz1-description").innerText = obj[0].description;
													document
															.getElementById("real-quiz2-id").innerText = obj[1].id;
													document
															.getElementById("quiz2-title").innerText = obj[1].headline;
													document
															.getElementById("quiz2-description").innerText = obj[1].description;
												}
											}
										}
									});
				})

function countdown(timeleft, divCountdown) {
	var questionDiv = divCountdown.parentNode;
	var downloadTimer = setInterval(function() {
		divCountdown.innerHTML = "Time: " + "<span>" + timeleft + "</span>"
				+ " seconds";
		timeleft -= 1;
		if (timeleft < 0) {
			clearInterval(downloadTimer);
			divCountdown.innerHTML = "Time is up!"
		}
	}, 1000);
	questionDiv.id = downloadTimer;
}

function calculatePoints(btn, answers, pointForCorrectAnswer, quizId) {
	pointForCorrectAnswer = parseInt(pointForCorrectAnswer);
	var answerDiv = btn.parentNode.parentNode;
	var parentDiv = answerDiv.parentNode;
	console.log(parentDiv.parentNode.parentNode)
	var scoreInput = parentDiv.parentNode.parentNode.lastElementChild;

	var childs = btn.parentNode.previousSibling.children;
	var time = btn.parentNode.nextSibling.innerHTML;
	var correct = true;

	if (time != "Time is up!") {
		for (var i = 0; i < childs.length; i++) {
			var isChecked = childs[i].lastElementChild.firstElementChild.checked;
			if ((!isChecked && answers[i].isCorrect)
					|| (isChecked && !answers[i].isCorrect)) {
				correct = false;
				break;
			}
		}
		if (correct)
			scoreInput.value = parseInt(scoreInput.value)
					+ pointForCorrectAnswer;
	}

	console.log(scoreInput.value)
}

function firstSkippedQuestion(id, thisDiv, divCountdown) {
	if (id == "question-card1") {
		var skipped1 = document.getElementsByClassName("skipped1");
		if (skipped1.length != 0) {
			var answer = confirm("Answer skipped questions?");
			if (answer) {
				$(thisDiv).fadeOut(1000);
				var restTime = skipped1[0].lastChild.firstElementChild.innerText;
				var divCountdown = skipped1[0].lastElementChild;

				setTimeout(function() {
					$(skipped1[0]).fadeIn(1500);
				}, 1000);
				countdown(restTime, divCountdown);
			} else {
				var div = document.getElementById(id).parentNode.parentNode;
				var quizId = div.firstElementChild.firstElementChild.innerHTML;
				div.lastElementChild.id = quizId;
				displayFormData(div);
			}
		} else {
			var div = document.getElementById(id).parentNode.parentNode;
			var quizId = div.firstElementChild.firstElementChild.innerHTML;
			div.lastElementChild.id = quizId;
			displayFormData(div);
		}
	} else {
		var skipped2 = document.getElementsByClassName("skipped2");
		if (skipped2.length != 0) {
			var answer = confirm("Answer skipped questions?");
			if (answer) {
				$(thisDiv).fadeOut(1000);
				var restTime = skipped2[0].lastChild.firstElementChild.innerText;
				var divCountdown = skipped2[0].lastElementChild;

				setTimeout(function() {
					$(skipped2[0]).fadeIn(1500);
				}, 1000);
				countdown(restTime, divCountdown);
			} else {
				var div = document.getElementById(id).parentNode.parentNode;
				var quizId = div.firstElementChild.firstElementChild.innerHTML;
				div.lastElementChild.id = quizId;
				displayFormData(div);
			}
		} else {
			console.log("skipped2")
			var div = document.getElementById(id).parentNode.parentNode;
			var quizId = div.firstElementChild.firstElementChild.innerHTML;
			div.lastElementChild.id = quizId;
			displayFormData(div);
		}
	}
}

function displayFormData(div) {
	var parent = div.parentNode;
	var divFinish = document.createElement("div");
	var form = document.createElement("form");

	form.method = "POST";
	form.id = "data-form"
	var title = document.createElement("h4");
	title.innerHTML = "Please enter information about yourself";
	title.setAttribute("style", "margin: 15px");

	var firstName = document.createElement("input");
	firstName.classList.add("form-control");
	firstName.placeholder = "First name";
	firstName.setAttribute("style", "margin-top: 15px")
	firstName.required = true;
	firstName.name = "firstName";

	var lastName = document.createElement("input");
	lastName.classList.add("form-control");
	lastName.placeholder = "Last name";
	lastName.setAttribute("style", "margin-top: 15px")
	lastName.name = "lastName";
	lastName.required = true;

	var email = document.createElement("input");
	email.classList.add("form-control");
	email.placeholder = "Email"
	email.setAttribute("style", "margin-top: 15px");
	email.name = "email";
	email.required = true;

	var button = document.createElement("button");
	button.classList.add("btn");
	button.classList.add("btn-default");
	button.classList.add("float-right");
	button.setAttribute("style", "margin-top: 15px")
	button.setAttribute("style", "background:rgb(12,190,12)");

	button.innerHTML = "Save";
	button.setAttribute("type", "submit");
	button.addEventListener("click", function(event) {

		if (form.checkValidity()) {
			event.preventDefault();
			var p = {
				p : "saveData",
				quizId : div.lastElementChild.id,
				points : div.lastElementChild.value,
				firstName : firstName.value,
				lastName : lastName.value,
				email : email.value
			};
			var pathname = location.pathname;
			$.post(pathname, $.param(p), function(response) {
				var message = document.createElement("div");
				message.setAttribute("style", "margin-top:10px")

				if (p.points < response / 2) {
					message.innerHTML = p.firstName + ", you have " + p.points
							+ "/" + response + ". More luck next time!"
				} else {
					message.innerHTML = "Congratulation," + p.firstName
							+ "! You won " + p.points + "/" + response + "!"
				}
				divFinish.innerHTML = "";
				divFinish.setAttribute("style", "text-align:center")
				divFinish.appendChild(message);
			});
		}
	})

	form.appendChild(title);
	form.appendChild(firstName);
	form.appendChild(lastName);
	form.appendChild(email);
	form.appendChild(button);
	divFinish.appendChild(form);
	div.setAttribute("style", "display:none");
	parent.appendChild(divFinish);
}

$(".start-quiz")
		.click(
				function() {
					var quizDiv = $(this).closest('div')[0].children[0];
					var startButton = $(this).closest('div')[0].children[1];
					var qdChildren = quizDiv.children;
					var quizId = qdChildren[0].innerText;
					var questionDiv = qdChildren[3];

					// quiz description
					qdChildren[2].style.display = "none";
					startButton.style.display = "none";
					questionDiv.style.display = "block";

					var pathname = location.pathname;
					var params = {
						p : "getQuestions",
						quizId : quizId,
					};

					$
							.post(
									pathname,
									$.param(params),
									function(responseText) {
										var obj = JSON.parse(responseText);
										if (obj != null && obj[0] != null) {
											var count = 0;
											while (obj[count] != null) {
												var newDiv = document
														.createElement("div");
												var question = document
														.createElement("h5");
											
												question.innerText = obj[count].question;
												var answers = obj[count].answers;

												var icon = document
														.createElement("i");
										        icon.classList.add("mr-3");
												question.style.display = "inline";
												var ul = document
														.createElement("ol");
												ul.classList.add("m-2");

												var divButtons = document
														.createElement("div");
												divButtons.classList
														.add("float-right");
												var buttonSubmit = document
														.createElement("button");
												buttonSubmit.classList
														.add("btn");
												buttonSubmit.classList
														.add("btn-default");
												buttonSubmit.classList
														.add("mt-5");
												buttonSubmit.classList
														.add("mr-2");
												buttonSubmit.setAttribute("style", "background:rgb(12,190,12)");
												buttonSubmit.innerText = "Submit";

												var buttonSkip = document
														.createElement("button");
												buttonSkip.classList.add("btn");
												buttonSkip.classList
														.add("btn-default");
												buttonSkip.classList
														.add("mt-5");
												buttonSkip.setAttribute("style", "background:rgb(12,190,12)");

												var time = obj[count].time;
												var answers = obj[count].answers;
												var pointForCorrectAnswer = obj[count].pointForCorrectAnswer;

												buttonSkip
														.addEventListener(
																"click",
																function() {
																	var answersDiv = this.parentNode.parentNode;
																	var ulAnswers = answersDiv.children[2];
																	var liAnswers = ulAnswers.children;

																	for (var k = 0; k < liAnswers.length; ++k) {
																		var checkbox = liAnswers[k].lastElementChild.firstElementChild;
																		if (checkbox.checked)
																			checkbox.checked = false;
																	}

																	clearInterval(answersDiv.id);

																	var index = Array.prototype.indexOf
																			.call(
																					answersDiv.parentNode.children,
																					answersDiv);

																	$(
																			answersDiv)
																			.fadeOut(
																					1000);

																	var skipped1 = document
																			.getElementsByClassName("skipped1");
																	var skipped2 = document
																			.getElementsByClassName("skipped2");

																	if (skipped1.length != 0
																			&& answersDiv.classList
																					.contains("skipped1")
																			&& answersDiv.parentNode.id == "question-card1") {
																		var currentIndex = Array.prototype.indexOf
																				.call(
																						skipped1,
																						answersDiv);
																		var skippedNext = currentIndex == skipped1.length - 1 ? 0
																				: currentIndex + 1;
																		var restTime = skipped1[skippedNext].lastChild.firstElementChild.innerText;
																		var divCountdown = skipped1[skippedNext].lastChild;

																		countdown(
																				restTime,
																				divCountdown);
																		setTimeout(
																				function() {
																					$(
																							skipped1[skippedNext])
																							.fadeIn(
																									1500);
																				},
																				1000);
																	} else if (skipped2.length != 0
																			&& answersDiv.classList
																					.contains("skipped2")
																			&& answersDiv.parentNode.id == "question-card2") {
																		var currentIndex = Array.prototype.indexOf
																				.call(
																						skipped2,
																						answersDiv);
																		var skippedNext = currentIndex == skipped2.length - 1 ? 0
																				: currentIndex + 1;
																		var restTime = skipped2[skippedNext].lastChild.firstElementChild.innerText;
																		var divCountdown = skipped2[skippedNext].lastChild;

																		countdown(
																				restTime,
																				divCountdown);
																		setTimeout(
																				function() {
																					$(
																							skipped2[skippedNext])
																							.fadeIn(
																									1500);
																				},
																				1000);
																	} else {
																		time = this.parentNode.parentNode.children[4].innerHTML;

																		if (time != "Time is up!") {
																			if (answersDiv.parentNode.id == "question-card1")
																				answersDiv.classList
																						.add("skipped1");
																			else
																				answersDiv.classList
																						.add("skipped2");
																		}
																		if (answersDiv.parentNode.children.length - 1 == index)
																			firstSkippedQuestion(
																					answersDiv.parentNode.id,
																					this.parentNode.parentNode,
																					divCountdown)

																		var that = this;
																		setTimeout(
																				function() {
																					$(
																							that.parentNode.parentNode.nextElementSibling)
																							.fadeIn(
																									1500);
																				},
																				1000);

																		
																		if (index + 1 < answersDiv.parentNode.children.length)
																			countdown(
																					obj[index + 1].time,
																					that.parentNode.parentNode.nextElementSibling.lastElementChild);
																	}
																});

												buttonSubmit
														.addEventListener(
																"click",
																function() {
																	var answersDiv = this.parentNode.parentNode;
																	var index = Array.prototype.indexOf
																			.call(
																					answersDiv.parentNode.children,
																					answersDiv);
																	var skipped1 = document
																			.getElementsByClassName("skipped1");
																	var skipped2 = document
																			.getElementsByClassName("skipped2");

																	if (answersDiv.parentNode.id == "question-card1"
																			&& answersDiv.classList
																					.contains("skipped1")) {
																		console
																				.log("skipped")
																		answersDiv.classList
																				.remove("skipped1");

																		if (!(skipped1.length == 0)) {
																			var currentIndex = Array.prototype.indexOf
																					.call(
																							skipped1,
																							answersDiv);
																			var skippedNext = currentIndex == skipped1.length - 1 ? 0
																					: currentIndex + 1;
																			var restTime = skipped1[skippedNext].lastChild.firstElementChild.innerText;
																			var divCountdown = skipped1[skippedNext].lastChild;

																			countdown(
																					restTime,
																					divCountdown);
																			setTimeout(
																					function() {
																						$(
																								skipped1[skippedNext])
																								.fadeIn(
																										1500);
																					},
																					1000);
																		} else {
																			var div = answersDiv.parentNode.parentNode.parentNode;
																			var quizId = div.firstElementChild.firstElementChild.innerHTML;
																			var div = answersDiv.parentNode.parentNode.parentNode;
																			var quizId = div.firstElementChild.firstElementChild.innerHTML;
																			div.lastElementChild.id = quizId;
																			displayFormData(div);
																		}
																	} else if (answersDiv.parentNode.id == "question-card2"
																			&& answersDiv.classList
																					.contains("skipped2")) {
																		answersDiv.classList
																				.remove("skipped2");

																		if (!(skipped2.length == 0)) {
																			var currentIndex = Array.prototype.indexOf
																					.call(
																							skipped2,
																							answersDiv);
																			var skippedNext = currentIndex == skipped2.length - 1 ? 0
																					: currentIndex + 1;
																			var restTime = skipped2[skippedNext].lastChild.firstElementChild.innerText;
																			var divCountdown = skipped2[skippedNext].lastChild;

																			countdown(
																					restTime,
																					divCountdown);
																			setTimeout(
																					function() {
																						$(
																								skipped2[skippedNext])
																								.fadeIn(
																										1500);
																					},
																					1000);
																		} else {
																			var div = answersDiv.parentNode.parentNode.parentNode;
																			var quizId = div.firstElementChild.firstElementChild.innerHTML;
																			div.lastElementChild.id = quizId;
																			displayFormData(div);
																		}
																	} else {
																		console
																				.log("answered")
																		var that = this;
																		setTimeout(
																				function() {
																					$(
																							that.parentNode.parentNode.nextElementSibling)
																							.fadeIn(
																									1500);
																				},
																				1000);
																		if (index + 1 < answersDiv.parentNode.children.length)
																			countdown(
																					obj[index + 1].time,
																					that.parentNode.parentNode.nextElementSibling.lastElementChild)
																	}

																	$(
																			answersDiv)
																			.fadeOut(
																					1000);
																	calculatePoints(
																			this,
																			obj[index].answers,
																			obj[index].pointForCorrectAnswer,
																			quizId);
																});

												buttonSkip.innerText = "Skip";
												divButtons
														.appendChild(buttonSubmit);
												divButtons
														.appendChild(buttonSkip);

												var divCountdown = document
														.createElement("div");
												divCountdown.classList
														.add("mt-4");

												newDiv.appendChild(icon);
												newDiv.appendChild(question);
												newDiv.appendChild(ul);
												newDiv.appendChild(divButtons);

												var j = 0;

												if (answers != null) {
													while (answers[j] != undefined) {
														var node = document
																.createElement("li");
														var textnode = document
																.createElement("label");
														var label = document
																.createElement("label");
														var input = "<input type='checkbox' class='option-input checkbox' name=''/>";
														textnode.style.width = "85%";
														textnode.innerText = answers[j].answer;
														label.innerHTML = input;
														node
																.appendChild(textnode);

														node.appendChild(label);
														ul.appendChild(node);

														++j;
													}
												}
												newDiv
														.appendChild(divCountdown);

												if (count == 0) {
													countdown(obj[0].time,
															divCountdown);

													$(newDiv).fadeIn(1500);
												} else
													newDiv.style.display = "none";

												if (obj[count + 1] == null) {
													buttonSubmit
															.addEventListener(
																	"click",
																	function() {
																		var answersDiv = this.parentNode.parentNode;
																		
																		var index = Array.prototype.indexOf
																				.call(
																						answersDiv.parentNode.children,
																						answersDiv);
																		firstSkippedQuestion(
																				answersDiv.parentNode.id,
																				this.parentNode.parentNode,
																				divCountdown)
																	});
												}
												questionDiv.appendChild(newDiv);
												count++;
											}
										}
									});
				});
